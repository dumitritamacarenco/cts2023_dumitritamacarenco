package ro.ase.acs.Decorator;

public interface ICard {
	public void payOnline(double suma);
	public void payPOS(double suma);

}
