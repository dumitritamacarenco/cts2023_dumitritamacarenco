package ro.ase.acs.Adapter.NewFramework;

public class CreditLeasing {
	
	public void oferaLeasing(int suma) {
		System.out.println("A fost oferit leasing: "+suma);
	}

}
