package ro.ase.acs.Adapter;

public interface Credit {
	
	public void oferaCredit(int suma);

}
